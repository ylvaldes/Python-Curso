#!/usr/bin/env python3
numbers=['one','two','three']
n=0
while(n<len(numbers)):print(numbers[n],end=' ');n+=1
print()
