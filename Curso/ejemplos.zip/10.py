#!/usr/bin/env python3
x='hello'
c=x.capitalize()
u=x.upper()
l=x.lower()
print('{} -> {} -> {} -> {}'.format(x,c,u,l))
