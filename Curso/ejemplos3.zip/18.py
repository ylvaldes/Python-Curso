#!/usr/bin/env python3
def main():colors=['red','green','blue'];print_list(colors)
def print_list(o):
    for i in o:print(i,end=' ')
    print()
if __name__ == '__main__': main()
