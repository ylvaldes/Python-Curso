#!/usr/bin/env python3
t='En un lugar de la Mancha de cuyo nombre no quiero acordarme'
l=t.split()
c=':'.join(l)
d='-'.join(l)
k=','.join(l)
s=';'.join(l)
for x in t,c,d,k,s:print(x)
