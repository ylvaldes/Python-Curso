#!/usr/bin/env python3
print('Hello!')
x='World';print('Hello, {}!'.format(x))
y='Hello, {}!. I am an object.'.format(x);print(y)
z=2018;print('This year is {}.'.format(z))
print('Hello, {}! This year is {}.'.format(x,z))
