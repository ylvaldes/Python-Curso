#!/usr/bin/env python3
list=['one',1,1.0,True,None]
for x in list:print('{} is of type:'.format(x),type(x))
